﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cine
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void btClientes_Click(object sender, EventArgs e)
        {
            FrmCliente frmCliente = new FrmCliente();
            frmCliente.ShowDialog();
        }

        private void btClasificacion_Click(object sender, EventArgs e)
        {
            FrmClasificacion frmClasificacion = new FrmClasificacion();
            frmClasificacion.ShowDialog();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btGenero_Click(object sender, EventArgs e)
        {
            FrmGenero frmGenero = new FrmGenero();
            frmGenero.ShowDialog();
        }

        private void btPelicula_Click(object sender, EventArgs e)
        {
            FrmPelicula frmPelicula = new FrmPelicula();
            frmPelicula.ShowDialog();
        }

        private void btSucursal_Click(object sender, EventArgs e)
        {
            FrmSucursal frmSucursal = new FrmSucursal();
            frmSucursal.ShowDialog();

        }

        private void btSala_Click(object sender, EventArgs e)
        {
            FrmSala frmSala = new FrmSala();
            frmSala.ShowDialog();
        }

        private void btTipoBoleto_Click(object sender, EventArgs e)
        {
            FrmTipoBoleto frmTipoBoleto = new FrmTipoBoleto();
            frmTipoBoleto.ShowDialog();
        }

        private void btUbicacion_Click(object sender, EventArgs e)
        {
            FrmUbicacion frmUbicacion = new FrmUbicacion();
            frmUbicacion.ShowDialog();
        }

        private void btFuncion_Click(object sender, EventArgs e)
        {
            FrmFuncion frmFuncion = new FrmFuncion();
            frmFuncion.ShowDialog();
        }

        private void btVenta_Click(object sender, EventArgs e)
        {
            FrmVenta frmVenta = new FrmVenta();
            frmVenta.ShowDialog();
        }
    }
}
