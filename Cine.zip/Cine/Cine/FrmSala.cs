﻿using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cine
{
    public partial class FrmSala : Form
    {

        private string cadenaConexion = @"Server=.\SQLEXPRESS;Database=Cine;Integrated Security=True;TrustServerCertificate=True;";
        private SqlDataAdapter adaptador;
        private DataTable tabla;
        private string modo = "";
        private DataRow filaEditando;
        public FrmSala()
        {
            InitializeComponent();
        }

        private void CargarSalas()
        {
            adaptador = new SqlDataAdapter("SELECT * FROM dbo.Sala", cadenaConexion);

            SqlCommandBuilder constructor = new SqlCommandBuilder(adaptador);

            adaptador.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            tabla = new DataTable();
            adaptador.Fill(tabla);

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = tabla;
        }

        private void CargarComboSucursales()
        {
            SqlDataAdapter adaptadorCombo = new SqlDataAdapter(
                "SELECT IDSucursal, Nombre FROM dbo.Sucursal ORDER BY Nombre",
                cadenaConexion);

            DataTable tablaCombo = new DataTable();
            adaptadorCombo.Fill(tablaCombo);

            cbSucursal.DataSource = tablaCombo;
            cbSucursal.DisplayMember = "Nombre";
            cbSucursal.ValueMember = "IDSucursal";
            cbSucursal.SelectedIndex = -1;
        }

        private void LimpiarCampos()
        {
            tbIDSala.Clear();
            cbSucursal.SelectedIndex = -1;
            tbNumeroSala.Clear();
            tbTipoSala.Clear();
            tbCantidadAsientos.Clear();
        }

        private void FrmSala_Load(object sender, EventArgs e)
        {
            CargarSalas();
            CargarComboSucursales();
        }

        private void btNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            modo = "nuevo";

            tbIDSala.ReadOnly = tabla.Columns["IDSala"].AutoIncrement;

            cbSucursal.Focus();
        }

        private void btEditar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una sala en la tabla.");
                return;
            }

            filaEditando = ((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;

            tbIDSala.Text = filaEditando["IDSala"].ToString();
            cbSucursal.SelectedValue = filaEditando["IDSucursal"];
            tbNumeroSala.Text = filaEditando["NumeroSala"].ToString();
            tbTipoSala.Text = filaEditando["TipoSala"].ToString();
            tbCantidadAsientos.Text = filaEditando["CantidadAsientos"].ToString();

            tbIDSala.ReadOnly = true;

            modo = "editar";
            cbSucursal.Focus();
        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una sala en la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Eliminar la sala seleccionada?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                DataRowView filaSeleccionada = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
                filaSeleccionada.Row.Delete();

                adaptador.Update(tabla);

                modo = "";
                LimpiarCampos();
                CargarSalas();

                MessageBox.Show("Sala eliminada.");
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo eliminar: " + ex.Message);
            }
        }

        private void btGuardar_Click(object sender, EventArgs e)
        {
            if (modo == "")
            {
                MessageBox.Show("Primero pulsa Nuevo o Editar.");
                return;
            }

            if (cbSucursal.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona una sucursal.");
                cbSucursal.Focus();
                return;
            }

            int numeroSala;
            if (!int.TryParse(tbNumeroSala.Text, out numeroSala) || numeroSala <= 0)
            {
                MessageBox.Show("El número de sala debe ser un número mayor a 0.");
                tbNumeroSala.Focus();
                return;
            }

            int cantidadAsientos;
            if (!int.TryParse(tbCantidadAsientos.Text, out cantidadAsientos) || cantidadAsientos <= 0)
            {
                MessageBox.Show("La cantidad de asientos debe ser un número mayor a 0.");
                tbCantidadAsientos.Focus();
                return;
            }

            int idSala = 0;
            if (!tabla.Columns["IDSala"].AutoIncrement &&
                !int.TryParse(tbIDSala.Text, out idSala))
            {
                MessageBox.Show("ID Sala debe ser un número.");
                tbIDSala.Focus();
                return;
            }

            int idSucursal = Convert.ToInt32(cbSucursal.SelectedValue);

            try
            {
                if (modo == "nuevo")
                {
                    DataRow fila = tabla.NewRow();

                    if (!tabla.Columns["IDSala"].AutoIncrement)
                        fila["IDSala"] = idSala;

                    fila["IDSucursal"] = idSucursal;
                    fila["NumeroSala"] = numeroSala;
                    fila["TipoSala"] = tbTipoSala.Text.Trim() == "" ? (object)DBNull.Value : tbTipoSala.Text.Trim();
                    fila["CantidadAsientos"] = cantidadAsientos;

                    tabla.Rows.Add(fila);
                }
                else if (modo == "editar")
                {
                    filaEditando["IDSucursal"] = idSucursal;
                    filaEditando["NumeroSala"] = numeroSala;
                    filaEditando["TipoSala"] = tbTipoSala.Text.Trim() == "" ? (object)DBNull.Value : tbTipoSala.Text.Trim();
                    filaEditando["CantidadAsientos"] = cantidadAsientos;
                }

                adaptador.Update(tabla);

                modo = "";
                LimpiarCampos();
                CargarSalas();

                MessageBox.Show("Sala guardada.");
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo guardar: " + ex.Message);
            }
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            modo = "";
            LimpiarCampos();
        }

        private void btObtener_Click(object sender, EventArgs e)
        {
            CargarSalas();
            CargarComboSucursales();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
