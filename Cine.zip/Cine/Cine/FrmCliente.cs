﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Cine
{
    public partial class FrmCliente : Form
    {
        private string cadenaConexion =
            @"Server=.\SQLEXPRESS;Database=Cine;Integrated Security=True;TrustServerCertificate=True;";
        private SqlDataAdapter adaptador;
        private DataTable tabla;
        private string modo = "";
        private DataRow filaEditando;

        public FrmCliente()
        {
            InitializeComponent();
        }

        private void CargarClientes()
        {
            adaptador = new SqlDataAdapter("SELECT * FROM dbo.Cliente", cadenaConexion);

            SqlCommandBuilder constructor = new SqlCommandBuilder(adaptador);

            adaptador.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            tabla = new DataTable();
            adaptador.Fill(tabla);

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = tabla;
        }

        private void LimpiarCampos()
        {
            tbIDCliente.Clear();
            tbIDCiudad.Clear();
            tbNombre.Clear();
            tbCelular.Clear();
            tbCorreo.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CargarClientes();
        }

        private void btNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            modo = "nuevo";

            tbIDCliente.ReadOnly = tabla.Columns["IDCliente"].AutoIncrement;

            tbNombre.Focus();
        }

        private void btGuardar_Click(object sender, EventArgs e)
        {
            if (modo == "")
            {
                MessageBox.Show("Primero pulsa Nuevo o Editar.");
                return;
            }

            if (tbNombre.Text.Trim() == "")
            {
                MessageBox.Show("El nombre es obligatorio.");
                tbNombre.Focus();
                return;
            }

            int idCiudad;
            if (!int.TryParse(tbIDCiudad.Text, out idCiudad))
            {
                MessageBox.Show("ID Ciudad debe ser un número.");
                tbIDCiudad.Focus();
                return;
            }

            int idCliente = 0;
            if (!tabla.Columns["IDCliente"].AutoIncrement &&
                !int.TryParse(tbIDCliente.Text, out idCliente))
            {
                MessageBox.Show("ID Cliente debe ser un número.");
                tbIDCliente.Focus();
                return;
            }

            try
            {
                if (modo == "nuevo")
                {
                    DataRow fila = tabla.NewRow();

                    if (!tabla.Columns["IDCliente"].AutoIncrement)
                        fila["IDCliente"] = idCliente;

                    fila["IDCiudad"] = idCiudad;
                    fila["Nombre"] = tbNombre.Text.Trim();
                    fila["Celular"] = tbCelular.Text.Trim() == "" ? (object)DBNull.Value : tbCelular.Text.Trim();
                    fila["Correo"] = tbCorreo.Text.Trim() == "" ? (object)DBNull.Value : tbCorreo.Text.Trim();

                    tabla.Rows.Add(fila);
                }
                else if (modo == "editar")
                {
                    filaEditando["IDCiudad"] = idCiudad;
                    filaEditando["Nombre"] = tbNombre.Text.Trim();
                    filaEditando["Celular"] = tbCelular.Text.Trim() == "" ? (object)DBNull.Value : tbCelular.Text.Trim();
                    filaEditando["Correo"] = tbCorreo.Text.Trim() == "" ? (object)DBNull.Value : tbCorreo.Text.Trim();
                }

                adaptador.Update(tabla);

                MessageBox.Show("Cliente guardado.");
                modo = "";
                LimpiarCampos();
                CargarClientes();
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo guardar: " + ex.Message);
            }
        }

        private void btEditar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona un cliente en la tabla.");
                return;
            }

            filaEditando = ((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;

            tbIDCliente.Text = filaEditando["IDCliente"].ToString();
            tbIDCiudad.Text = filaEditando["IDCiudad"].ToString();
            tbNombre.Text = filaEditando["Nombre"].ToString();
            tbCelular.Text = filaEditando["Celular"].ToString();
            tbCorreo.Text = filaEditando["Correo"].ToString();

            tbIDCliente.ReadOnly = true;

            modo = "editar";
            tbNombre.Focus();
        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona un cliente en la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Eliminar el cliente seleccionado?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                DataRowView filaSeleccionada = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
                filaSeleccionada.Row.Delete();

                adaptador.Update(tabla);

                MessageBox.Show("Cliente eliminado.");
                modo = "";
                LimpiarCampos();
                CargarClientes();
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo eliminar: " + ex.Message);
            }

        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            modo = "";
            LimpiarCampos();
        }

        private void btObtener_Click(object sender, EventArgs e)
        {
            CargarClientes();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}