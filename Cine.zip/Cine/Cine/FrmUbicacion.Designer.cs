﻿namespace Cine
{
    partial class FrmUbicacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUbicacion));
            this.tcUbicaciones = new System.Windows.Forms.TabControl();
            this.tbEstado = new System.Windows.Forms.TabPage();
            this.dgvEstados = new System.Windows.Forms.DataGridView();
            this.gbEstado = new System.Windows.Forms.GroupBox();
            this.tbNombreEstado = new System.Windows.Forms.TextBox();
            this.tbClaveEstado = new System.Windows.Forms.TextBox();
            this.tbSiglaEstado = new System.Windows.Forms.TextBox();
            this.tbIDEstado = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btNuevoEstado = new System.Windows.Forms.ToolStripButton();
            this.btEditarEstado = new System.Windows.Forms.ToolStripButton();
            this.btEliminarEstado = new System.Windows.Forms.ToolStripButton();
            this.btGuardarEstado = new System.Windows.Forms.ToolStripButton();
            this.btCancelarEstado = new System.Windows.Forms.ToolStripButton();
            this.btObtenerEstado = new System.Windows.Forms.ToolStripButton();
            this.btSalirEstado = new System.Windows.Forms.ToolStripButton();
            this.tbCiudades = new System.Windows.Forms.TabPage();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.btNuevoCiudad = new System.Windows.Forms.ToolStripButton();
            this.btEditarCiudad = new System.Windows.Forms.ToolStripButton();
            this.btEliminarCiudad = new System.Windows.Forms.ToolStripButton();
            this.btGuardarCiudad = new System.Windows.Forms.ToolStripButton();
            this.btCancelarCiudad = new System.Windows.Forms.ToolStripButton();
            this.btObtenerCiudad = new System.Windows.Forms.ToolStripButton();
            this.btSalirCiudad = new System.Windows.Forms.ToolStripButton();
            this.gbCiudad = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tbIDCiudad = new System.Windows.Forms.TextBox();
            this.tbSiglasCiudad = new System.Windows.Forms.TextBox();
            this.tbClaveCiudad = new System.Windows.Forms.TextBox();
            this.tbNombreCiudad = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cbEstado = new System.Windows.Forms.ComboBox();
            this.dgvCiudades = new System.Windows.Forms.DataGridView();
            this.tcUbicaciones.SuspendLayout();
            this.tbEstado.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstados)).BeginInit();
            this.gbEstado.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tbCiudades.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.gbCiudad.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCiudades)).BeginInit();
            this.SuspendLayout();
            // 
            // tcUbicaciones
            // 
            this.tcUbicaciones.Controls.Add(this.tbEstado);
            this.tcUbicaciones.Controls.Add(this.tbCiudades);
            this.tcUbicaciones.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcUbicaciones.Location = new System.Drawing.Point(0, 0);
            this.tcUbicaciones.Name = "tcUbicaciones";
            this.tcUbicaciones.SelectedIndex = 0;
            this.tcUbicaciones.Size = new System.Drawing.Size(800, 450);
            this.tcUbicaciones.TabIndex = 0;
            // 
            // tbEstado
            // 
            this.tbEstado.Controls.Add(this.dgvEstados);
            this.tbEstado.Controls.Add(this.gbEstado);
            this.tbEstado.Controls.Add(this.toolStrip1);
            this.tbEstado.Location = new System.Drawing.Point(4, 22);
            this.tbEstado.Name = "tbEstado";
            this.tbEstado.Padding = new System.Windows.Forms.Padding(3);
            this.tbEstado.Size = new System.Drawing.Size(792, 424);
            this.tbEstado.TabIndex = 0;
            this.tbEstado.Text = "Estados";
            this.tbEstado.UseVisualStyleBackColor = true;
            // 
            // dgvEstados
            // 
            this.dgvEstados.AllowUserToAddRows = false;
            this.dgvEstados.AllowUserToDeleteRows = false;
            this.dgvEstados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvEstados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEstados.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEstados.Location = new System.Drawing.Point(3, 178);
            this.dgvEstados.MultiSelect = false;
            this.dgvEstados.Name = "dgvEstados";
            this.dgvEstados.ReadOnly = true;
            this.dgvEstados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEstados.Size = new System.Drawing.Size(786, 243);
            this.dgvEstados.TabIndex = 7;
            // 
            // gbEstado
            // 
            this.gbEstado.Controls.Add(this.tbNombreEstado);
            this.gbEstado.Controls.Add(this.tbClaveEstado);
            this.gbEstado.Controls.Add(this.tbSiglaEstado);
            this.gbEstado.Controls.Add(this.tbIDEstado);
            this.gbEstado.Controls.Add(this.label4);
            this.gbEstado.Controls.Add(this.label3);
            this.gbEstado.Controls.Add(this.label2);
            this.gbEstado.Controls.Add(this.label1);
            this.gbEstado.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbEstado.Location = new System.Drawing.Point(3, 28);
            this.gbEstado.Name = "gbEstado";
            this.gbEstado.Size = new System.Drawing.Size(786, 150);
            this.gbEstado.TabIndex = 6;
            this.gbEstado.TabStop = false;
            this.gbEstado.Text = "Datos del Estado";
            // 
            // tbNombreEstado
            // 
            this.tbNombreEstado.Location = new System.Drawing.Point(462, 31);
            this.tbNombreEstado.Name = "tbNombreEstado";
            this.tbNombreEstado.Size = new System.Drawing.Size(206, 20);
            this.tbNombreEstado.TabIndex = 7;
            // 
            // tbClaveEstado
            // 
            this.tbClaveEstado.Location = new System.Drawing.Point(92, 124);
            this.tbClaveEstado.Name = "tbClaveEstado";
            this.tbClaveEstado.Size = new System.Drawing.Size(194, 20);
            this.tbClaveEstado.TabIndex = 6;
            // 
            // tbSiglaEstado
            // 
            this.tbSiglaEstado.Location = new System.Drawing.Point(92, 86);
            this.tbSiglaEstado.Name = "tbSiglaEstado";
            this.tbSiglaEstado.Size = new System.Drawing.Size(194, 20);
            this.tbSiglaEstado.TabIndex = 5;
            // 
            // tbIDEstado
            // 
            this.tbIDEstado.Location = new System.Drawing.Point(92, 39);
            this.tbIDEstado.Name = "tbIDEstado";
            this.tbIDEstado.Size = new System.Drawing.Size(194, 20);
            this.tbIDEstado.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(395, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Nombre";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Clave";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Sigla";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID Estado";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btNuevoEstado,
            this.btEditarEstado,
            this.btEliminarEstado,
            this.btGuardarEstado,
            this.btCancelarEstado,
            this.btObtenerEstado,
            this.btSalirEstado});
            this.toolStrip1.Location = new System.Drawing.Point(3, 3);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.toolStrip1.Size = new System.Drawing.Size(786, 25);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btNuevoEstado
            // 
            this.btNuevoEstado.Image = ((System.Drawing.Image)(resources.GetObject("btNuevoEstado.Image")));
            this.btNuevoEstado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btNuevoEstado.Name = "btNuevoEstado";
            this.btNuevoEstado.Size = new System.Drawing.Size(62, 22);
            this.btNuevoEstado.Text = "Nuevo";
            this.btNuevoEstado.Click += new System.EventHandler(this.btNuevoEstado_Click);
            // 
            // btEditarEstado
            // 
            this.btEditarEstado.Image = ((System.Drawing.Image)(resources.GetObject("btEditarEstado.Image")));
            this.btEditarEstado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btEditarEstado.Name = "btEditarEstado";
            this.btEditarEstado.Size = new System.Drawing.Size(57, 22);
            this.btEditarEstado.Text = "Editar";
            this.btEditarEstado.Click += new System.EventHandler(this.btEditarEstado_Click);
            // 
            // btEliminarEstado
            // 
            this.btEliminarEstado.Image = ((System.Drawing.Image)(resources.GetObject("btEliminarEstado.Image")));
            this.btEliminarEstado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btEliminarEstado.Name = "btEliminarEstado";
            this.btEliminarEstado.Size = new System.Drawing.Size(70, 22);
            this.btEliminarEstado.Text = "Eliminar";
            this.btEliminarEstado.Click += new System.EventHandler(this.btEliminarEstado_Click);
            // 
            // btGuardarEstado
            // 
            this.btGuardarEstado.Image = ((System.Drawing.Image)(resources.GetObject("btGuardarEstado.Image")));
            this.btGuardarEstado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btGuardarEstado.Name = "btGuardarEstado";
            this.btGuardarEstado.Size = new System.Drawing.Size(69, 22);
            this.btGuardarEstado.Text = "Guardar";
            this.btGuardarEstado.Click += new System.EventHandler(this.btGuardarEstado_Click);
            // 
            // btCancelarEstado
            // 
            this.btCancelarEstado.Image = ((System.Drawing.Image)(resources.GetObject("btCancelarEstado.Image")));
            this.btCancelarEstado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btCancelarEstado.Name = "btCancelarEstado";
            this.btCancelarEstado.Size = new System.Drawing.Size(73, 22);
            this.btCancelarEstado.Text = "Cancelar";
            this.btCancelarEstado.Click += new System.EventHandler(this.btCancelarEstado_Click);
            // 
            // btObtenerEstado
            // 
            this.btObtenerEstado.Image = ((System.Drawing.Image)(resources.GetObject("btObtenerEstado.Image")));
            this.btObtenerEstado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btObtenerEstado.Name = "btObtenerEstado";
            this.btObtenerEstado.Size = new System.Drawing.Size(103, 22);
            this.btObtenerEstado.Text = "Obtener Datos";
            this.btObtenerEstado.Click += new System.EventHandler(this.btObtenerEstado_Click);
            // 
            // btSalirEstado
            // 
            this.btSalirEstado.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btSalirEstado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btSalirEstado.Image = ((System.Drawing.Image)(resources.GetObject("btSalirEstado.Image")));
            this.btSalirEstado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btSalirEstado.Name = "btSalirEstado";
            this.btSalirEstado.Size = new System.Drawing.Size(33, 22);
            this.btSalirEstado.Text = "Salir";
            this.btSalirEstado.Click += new System.EventHandler(this.btSalirEstado_Click);
            // 
            // tbCiudades
            // 
            this.tbCiudades.Controls.Add(this.dgvCiudades);
            this.tbCiudades.Controls.Add(this.gbCiudad);
            this.tbCiudades.Controls.Add(this.toolStrip2);
            this.tbCiudades.Location = new System.Drawing.Point(4, 22);
            this.tbCiudades.Name = "tbCiudades";
            this.tbCiudades.Padding = new System.Windows.Forms.Padding(3);
            this.tbCiudades.Size = new System.Drawing.Size(792, 424);
            this.tbCiudades.TabIndex = 1;
            this.tbCiudades.Text = "Ciudades";
            this.tbCiudades.UseVisualStyleBackColor = true;
            // 
            // toolStrip2
            // 
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btNuevoCiudad,
            this.btEditarCiudad,
            this.btEliminarCiudad,
            this.btGuardarCiudad,
            this.btCancelarCiudad,
            this.btObtenerCiudad,
            this.btSalirCiudad});
            this.toolStrip2.Location = new System.Drawing.Point(3, 3);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Padding = new System.Windows.Forms.Padding(0);
            this.toolStrip2.Size = new System.Drawing.Size(786, 25);
            this.toolStrip2.TabIndex = 5;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // btNuevoCiudad
            // 
            this.btNuevoCiudad.Image = ((System.Drawing.Image)(resources.GetObject("btNuevoCiudad.Image")));
            this.btNuevoCiudad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btNuevoCiudad.Name = "btNuevoCiudad";
            this.btNuevoCiudad.Size = new System.Drawing.Size(62, 22);
            this.btNuevoCiudad.Text = "Nuevo";
            this.btNuevoCiudad.Click += new System.EventHandler(this.btNuevoCiudad_Click);
            // 
            // btEditarCiudad
            // 
            this.btEditarCiudad.Image = ((System.Drawing.Image)(resources.GetObject("btEditarCiudad.Image")));
            this.btEditarCiudad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btEditarCiudad.Name = "btEditarCiudad";
            this.btEditarCiudad.Size = new System.Drawing.Size(57, 22);
            this.btEditarCiudad.Text = "Editar";
            this.btEditarCiudad.Click += new System.EventHandler(this.btEditarCiudad_Click);
            // 
            // btEliminarCiudad
            // 
            this.btEliminarCiudad.Image = ((System.Drawing.Image)(resources.GetObject("btEliminarCiudad.Image")));
            this.btEliminarCiudad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btEliminarCiudad.Name = "btEliminarCiudad";
            this.btEliminarCiudad.Size = new System.Drawing.Size(70, 22);
            this.btEliminarCiudad.Text = "Eliminar";
            this.btEliminarCiudad.Click += new System.EventHandler(this.btEliminarCiudad_Click);
            // 
            // btGuardarCiudad
            // 
            this.btGuardarCiudad.Image = ((System.Drawing.Image)(resources.GetObject("btGuardarCiudad.Image")));
            this.btGuardarCiudad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btGuardarCiudad.Name = "btGuardarCiudad";
            this.btGuardarCiudad.Size = new System.Drawing.Size(69, 22);
            this.btGuardarCiudad.Text = "Guardar";
            this.btGuardarCiudad.Click += new System.EventHandler(this.btGuardarCiudad_Click);
            // 
            // btCancelarCiudad
            // 
            this.btCancelarCiudad.Image = ((System.Drawing.Image)(resources.GetObject("btCancelarCiudad.Image")));
            this.btCancelarCiudad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btCancelarCiudad.Name = "btCancelarCiudad";
            this.btCancelarCiudad.Size = new System.Drawing.Size(73, 22);
            this.btCancelarCiudad.Text = "Cancelar";
            this.btCancelarCiudad.Click += new System.EventHandler(this.btCancelarCiudad_Click);
            // 
            // btObtenerCiudad
            // 
            this.btObtenerCiudad.Image = ((System.Drawing.Image)(resources.GetObject("btObtenerCiudad.Image")));
            this.btObtenerCiudad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btObtenerCiudad.Name = "btObtenerCiudad";
            this.btObtenerCiudad.Size = new System.Drawing.Size(103, 22);
            this.btObtenerCiudad.Text = "Obtener Datos";
            this.btObtenerCiudad.Click += new System.EventHandler(this.btObtenerCiudad_Click);
            // 
            // btSalirCiudad
            // 
            this.btSalirCiudad.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btSalirCiudad.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btSalirCiudad.Image = ((System.Drawing.Image)(resources.GetObject("btSalirCiudad.Image")));
            this.btSalirCiudad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btSalirCiudad.Name = "btSalirCiudad";
            this.btSalirCiudad.Size = new System.Drawing.Size(33, 22);
            this.btSalirCiudad.Text = "Salir";
            this.btSalirCiudad.Click += new System.EventHandler(this.btSalirCiudad_Click);
            // 
            // gbCiudad
            // 
            this.gbCiudad.Controls.Add(this.cbEstado);
            this.gbCiudad.Controls.Add(this.label9);
            this.gbCiudad.Controls.Add(this.tbNombreCiudad);
            this.gbCiudad.Controls.Add(this.tbClaveCiudad);
            this.gbCiudad.Controls.Add(this.tbSiglasCiudad);
            this.gbCiudad.Controls.Add(this.tbIDCiudad);
            this.gbCiudad.Controls.Add(this.label8);
            this.gbCiudad.Controls.Add(this.label7);
            this.gbCiudad.Controls.Add(this.label6);
            this.gbCiudad.Controls.Add(this.label5);
            this.gbCiudad.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbCiudad.Location = new System.Drawing.Point(3, 28);
            this.gbCiudad.Name = "gbCiudad";
            this.gbCiudad.Size = new System.Drawing.Size(786, 134);
            this.gbCiudad.TabIndex = 6;
            this.gbCiudad.TabStop = false;
            this.gbCiudad.Text = "Datos de la  ciudad";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "ID Ciudad";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Estado";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 108);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "Siglas";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(391, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Clave";
            // 
            // tbIDCiudad
            // 
            this.tbIDCiudad.Location = new System.Drawing.Point(67, 27);
            this.tbIDCiudad.Name = "tbIDCiudad";
            this.tbIDCiudad.Size = new System.Drawing.Size(217, 20);
            this.tbIDCiudad.TabIndex = 4;
            // 
            // tbSiglasCiudad
            // 
            this.tbSiglasCiudad.Location = new System.Drawing.Point(67, 105);
            this.tbSiglasCiudad.MaxLength = 5;
            this.tbSiglasCiudad.Name = "tbSiglasCiudad";
            this.tbSiglasCiudad.Size = new System.Drawing.Size(217, 20);
            this.tbSiglasCiudad.TabIndex = 6;
            // 
            // tbClaveCiudad
            // 
            this.tbClaveCiudad.Location = new System.Drawing.Point(448, 27);
            this.tbClaveCiudad.Name = "tbClaveCiudad";
            this.tbClaveCiudad.Size = new System.Drawing.Size(175, 20);
            this.tbClaveCiudad.TabIndex = 7;
            // 
            // tbNombreCiudad
            // 
            this.tbNombreCiudad.Location = new System.Drawing.Point(448, 68);
            this.tbNombreCiudad.MaxLength = 200;
            this.tbNombreCiudad.Name = "tbNombreCiudad";
            this.tbNombreCiudad.Size = new System.Drawing.Size(175, 20);
            this.tbNombreCiudad.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(391, 75);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Nombre";
            // 
            // cbEstado
            // 
            this.cbEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEstado.FormattingEnabled = true;
            this.cbEstado.Location = new System.Drawing.Point(67, 65);
            this.cbEstado.Name = "cbEstado";
            this.cbEstado.Size = new System.Drawing.Size(217, 21);
            this.cbEstado.TabIndex = 10;
            // 
            // dgvCiudades
            // 
            this.dgvCiudades.AllowUserToAddRows = false;
            this.dgvCiudades.AllowUserToDeleteRows = false;
            this.dgvCiudades.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCiudades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCiudades.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCiudades.Location = new System.Drawing.Point(3, 162);
            this.dgvCiudades.MultiSelect = false;
            this.dgvCiudades.Name = "dgvCiudades";
            this.dgvCiudades.ReadOnly = true;
            this.dgvCiudades.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCiudades.Size = new System.Drawing.Size(786, 259);
            this.dgvCiudades.TabIndex = 7;
            // 
            // FrmUbicacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tcUbicaciones);
            this.Name = "FrmUbicacion";
            this.Text = "Ubicaciones";
            this.Load += new System.EventHandler(this.FrmUbicacion_Load);
            this.tcUbicaciones.ResumeLayout(false);
            this.tbEstado.ResumeLayout(false);
            this.tbEstado.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstados)).EndInit();
            this.gbEstado.ResumeLayout(false);
            this.gbEstado.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tbCiudades.ResumeLayout(false);
            this.tbCiudades.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.gbCiudad.ResumeLayout(false);
            this.gbCiudad.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCiudades)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcUbicaciones;
        private System.Windows.Forms.TabPage tbEstado;
        private System.Windows.Forms.TabPage tbCiudades;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btNuevoEstado;
        private System.Windows.Forms.ToolStripButton btEditarEstado;
        private System.Windows.Forms.ToolStripButton btEliminarEstado;
        private System.Windows.Forms.ToolStripButton btGuardarEstado;
        private System.Windows.Forms.ToolStripButton btCancelarEstado;
        private System.Windows.Forms.ToolStripButton btObtenerEstado;
        private System.Windows.Forms.ToolStripButton btSalirEstado;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton btNuevoCiudad;
        private System.Windows.Forms.ToolStripButton btEditarCiudad;
        private System.Windows.Forms.ToolStripButton btEliminarCiudad;
        private System.Windows.Forms.ToolStripButton btGuardarCiudad;
        private System.Windows.Forms.ToolStripButton btCancelarCiudad;
        private System.Windows.Forms.ToolStripButton btObtenerCiudad;
        private System.Windows.Forms.ToolStripButton btSalirCiudad;
        private System.Windows.Forms.GroupBox gbEstado;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvEstados;
        private System.Windows.Forms.TextBox tbNombreEstado;
        private System.Windows.Forms.TextBox tbClaveEstado;
        private System.Windows.Forms.TextBox tbSiglaEstado;
        private System.Windows.Forms.TextBox tbIDEstado;
        private System.Windows.Forms.GroupBox gbCiudad;
        private System.Windows.Forms.TextBox tbClaveCiudad;
        private System.Windows.Forms.TextBox tbSiglasCiudad;
        private System.Windows.Forms.TextBox tbIDCiudad;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbNombreCiudad;
        private System.Windows.Forms.ComboBox cbEstado;
        private System.Windows.Forms.DataGridView dgvCiudades;
    }
}