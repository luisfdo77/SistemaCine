﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cine
{
    public partial class FrmSucursal : Form
    {
        private string cadenaConexion = @"Server=.\SQLEXPRESS;Database=Cine;Integrated Security=True;TrustServerCertificate=True;";
        private SqlDataAdapter adaptador;
        private DataTable tabla;
        private string modo = "";
        private DataRow filaEditando;
        public FrmSucursal()
        {
            InitializeComponent();
        }

        private void CargarSucursales()
        {
            adaptador = new SqlDataAdapter("SELECT * FROM dbo.Sucursal", cadenaConexion);

            SqlCommandBuilder constructor = new SqlCommandBuilder(adaptador);

            adaptador.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            tabla = new DataTable();
            adaptador.Fill(tabla);

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = tabla;
        }

        private void CargarComboCiudades()
        {
            SqlDataAdapter adaptadorCombo = new SqlDataAdapter(
                "SELECT IDCiudad, NombreCiudad FROM dbo.Ciudad ORDER BY NombreCiudad",
                cadenaConexion);

            DataTable tablaCombo = new DataTable();
            adaptadorCombo.Fill(tablaCombo);

            cbCiudad.DataSource = tablaCombo;
            cbCiudad.DisplayMember = "NombreCiudad";
            cbCiudad.ValueMember = "IDCiudad";
            cbCiudad.SelectedIndex = -1;
        }

        private void LimpiarCampos()
        {
            tbIDSucursal.Clear();
            tbNombre.Clear();
            cbCiudad.SelectedIndex = -1;
            tbDireccion.Clear();
        }

        private void FrmSucursal_Load(object sender, EventArgs e)
        {
            CargarSucursales();
            CargarComboCiudades();
        }

        private void btNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            modo = "nuevo";

            tbIDSucursal.ReadOnly = tabla.Columns["IDSucursal"].AutoIncrement;

            tbNombre.Focus();
        }

        private void btEditar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una sucursal en la tabla.");
                return;
            }

            filaEditando = ((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;

            tbIDSucursal.Text = filaEditando["IDSucursal"].ToString();
            tbNombre.Text = filaEditando["Nombre"].ToString();
            tbDireccion.Text = filaEditando["Direccion"].ToString();

            if (filaEditando["IDCiudad"] == DBNull.Value)
                cbCiudad.SelectedIndex = -1;
            else
                cbCiudad.SelectedValue = filaEditando["IDCiudad"];

            tbIDSucursal.ReadOnly = true;

            modo = "editar";
            tbNombre.Focus();
        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una sucursal en la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Eliminar la sucursal seleccionada?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                DataRowView filaSeleccionada = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
                filaSeleccionada.Row.Delete();

                adaptador.Update(tabla);

                modo = "";
                LimpiarCampos();
                CargarSucursales();

                MessageBox.Show("Sucursal eliminada.");
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo eliminar: " + ex.Message);
            }
        }

        private void btGuardar_Click(object sender, EventArgs e)
        {
            if (modo == "")
            {
                MessageBox.Show("Primero pulsa Nuevo o Editar.");
                return;
            }

            if (tbNombre.Text.Trim() == "")
            {
                MessageBox.Show("El nombre es obligatorio.");
                tbNombre.Focus();
                return;
            }

            if (cbCiudad.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona una ciudad.");
                cbCiudad.Focus();
                return;
            }

            int idSucursal = 0;
            if (!tabla.Columns["IDSucursal"].AutoIncrement &&
                !int.TryParse(tbIDSucursal.Text, out idSucursal))
            {
                MessageBox.Show("ID Sucursal debe ser un número.");
                tbIDSucursal.Focus();
                return;
            }

            int idCiudad = Convert.ToInt32(cbCiudad.SelectedValue);

            try
            {
                if (modo == "nuevo")
                {
                    DataRow fila = tabla.NewRow();

                    if (!tabla.Columns["IDSucursal"].AutoIncrement)
                        fila["IDSucursal"] = idSucursal;

                    fila["Nombre"] = tbNombre.Text.Trim();
                    fila["Direccion"] = tbDireccion.Text.Trim() == "" ? (object)DBNull.Value : tbDireccion.Text.Trim();
                    fila["IDCiudad"] = idCiudad;

                    tabla.Rows.Add(fila);
                }
                else if (modo == "editar")
                {
                    filaEditando["Nombre"] = tbNombre.Text.Trim();
                    filaEditando["Direccion"] = tbDireccion.Text.Trim() == "" ? (object)DBNull.Value : tbDireccion.Text.Trim();
                    filaEditando["IDCiudad"] = idCiudad;
                }

                adaptador.Update(tabla);

                MessageBox.Show("Sucursal guardada.");
                modo = "";
                LimpiarCampos();
                CargarSucursales();
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo guardar: " + ex.Message);
            }
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            modo = "";
            LimpiarCampos();
        }

        private void btObtener_Click(object sender, EventArgs e)
        {
            CargarSucursales();
            CargarComboCiudades();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
