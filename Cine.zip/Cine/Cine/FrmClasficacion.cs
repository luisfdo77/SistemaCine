﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cine
{
    public partial class FrmClasificacion : Form
    {
        private string cadenaConexion = @"Server=.\SQLEXPRESS;Database=Cine;Integrated Security=True;TrustServerCertificate=True;";
        private SqlDataAdapter adaptador;
        private DataTable tabla;
        private string modo = "";
        private DataRow filaEditando;


        public FrmClasificacion()
        {
            InitializeComponent();
        }

        private void CargarClasificaciones()
        {
            adaptador = new SqlDataAdapter("SELECT * FROM dbo.Clasificacion", cadenaConexion);

            SqlCommandBuilder constructor = new SqlCommandBuilder(adaptador);

            adaptador.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            tabla = new DataTable();
            adaptador.Fill(tabla);

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = tabla;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmClasificacion_Load(object sender, EventArgs e)
        {
            CargarClasificaciones();
        }

        private void LimpiarCampos()
        {
            tbIDClasificacion.Clear();
            tbClave.Clear();
            tbDescripcion.Clear();
        }

        private void btNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            modo = "nuevo";

            tbIDClasificacion.ReadOnly = tabla.Columns["IDClasificacion"].AutoIncrement;

            tbClave.Focus();

        }

        private void btEditar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una clasificación en la tabla.");
                return;
            }

            filaEditando = ((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;

            tbIDClasificacion.Text = filaEditando["IDClasificacion"].ToString();
            tbClave.Text = filaEditando["Clave"].ToString();
            tbDescripcion.Text = filaEditando["Descripcion"].ToString();

            tbIDClasificacion.ReadOnly = true;

            modo = "editar";
            tbClave.Focus();
        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una clasificación en la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Eliminar la clasificación seleccionada?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                DataRowView filaSeleccionada = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
                filaSeleccionada.Row.Delete();

                adaptador.Update(tabla);

                MessageBox.Show("Clasificación eliminada.");
                modo = "";
                LimpiarCampos();
                CargarClasificaciones();
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo eliminar: " + ex.Message);
            }
        }

        private void btGuardar_Click(object sender, EventArgs e)
        {
            if (modo == "")
            {
                MessageBox.Show("Primero pulsa Nuevo o Editar.");
                return;
            }

            if (tbClave.Text.Trim() == "")
            {
                MessageBox.Show("La clave es obligatoria.");
                tbClave.Focus();
                return;
            }

            int idClasificacion = 0;
            if (!tabla.Columns["IDClasificacion"].AutoIncrement &&
                !int.TryParse(tbIDClasificacion.Text, out idClasificacion))
            {
                MessageBox.Show("ID Clasificación debe ser un número.");
                tbIDClasificacion.Focus();
                return;
            }

            try
            {
                if (modo == "nuevo")
                {
                    DataRow fila = tabla.NewRow();

                    if (!tabla.Columns["IDClasificacion"].AutoIncrement)
                        fila["IDClasificacion"] = idClasificacion;

                    fila["Clave"] = tbClave.Text.Trim();
                    fila["Descripcion"] = tbDescripcion.Text.Trim() == "" ? (object)DBNull.Value : tbDescripcion.Text.Trim();
                    fila["FecharHoraCreacion"] = DateTime.Now;

                    tabla.Rows.Add(fila);
                }
                else if (modo == "editar")
                {
                    filaEditando["Clave"] = tbClave.Text.Trim();
                    filaEditando["Descripcion"] = tbDescripcion.Text.Trim() == "" ? (object)DBNull.Value : tbDescripcion.Text.Trim();
                }

                adaptador.Update(tabla);

                MessageBox.Show("Clasificación guardada.");
                modo = "";
                LimpiarCampos();
                CargarClasificaciones();
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo guardar: " + ex.Message);
            }

        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            modo = "";
            LimpiarCampos();
        }

        private void btObtener_Click(object sender, EventArgs e)
        {
            CargarClasificaciones();
        }
    }
}
