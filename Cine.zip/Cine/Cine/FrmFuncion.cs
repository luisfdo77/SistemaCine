﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cine
{
    public partial class FrmFuncion : Form
    {

        private string cadenaConexion =
    @"Server=.\SQLEXPRESS;Database=Cine;Integrated Security=True;TrustServerCertificate=True;";
        private SqlDataAdapter adaptador;
        private DataTable tabla;
        private string modo = "";
        private DataRow filaEditando;
        public FrmFuncion()
        {

            InitializeComponent();
        }

        private void CargarFunciones()
        {
            adaptador = new SqlDataAdapter("SELECT * FROM dbo.Funcion", cadenaConexion);

            SqlCommandBuilder constructor = new SqlCommandBuilder(adaptador);

            adaptador.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            tabla = new DataTable();
            adaptador.Fill(tabla);

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = tabla;
        }

        private void CargarComboPeliculas()
        {
            SqlDataAdapter adaptadorCombo = new SqlDataAdapter(
                "SELECT IDPelicula, NombrePelicula FROM dbo.Pelicula ORDER BY NombrePelicula",
                cadenaConexion);

            DataTable tablaCombo = new DataTable();
            adaptadorCombo.Fill(tablaCombo);

            cbPelicula.DataSource = tablaCombo;
            cbPelicula.DisplayMember = "NombrePelicula";
            cbPelicula.ValueMember = "IDPelicula";
            cbPelicula.SelectedIndex = -1;
        }

        private void CargarComboSalas()
        {
            SqlDataAdapter adaptadorCombo = new SqlDataAdapter(
                "SELECT s.IDSala, su.Nombre + ' - Sala ' + CAST(s.NumeroSala AS varchar) AS Descripcion " +
                "FROM dbo.Sala s INNER JOIN dbo.Sucursal su ON s.IDSucursal = su.IDSucursal " +
                "ORDER BY su.Nombre, s.NumeroSala",
                cadenaConexion);

            DataTable tablaCombo = new DataTable();
            adaptadorCombo.Fill(tablaCombo);

            cbSala.DataSource = tablaCombo;
            cbSala.DisplayMember = "Descripcion";
            cbSala.ValueMember = "IDSala";
            cbSala.SelectedIndex = -1;
        }

        private void LimpiarCampos()
        {
            tbIDFuncion.Clear();
            cbPelicula.SelectedIndex = -1;
            cbSala.SelectedIndex = -1;
            dtpFecha.Value = DateTime.Today;
            dtpHora.Value = DateTime.Today;
        }

        private void FrmFuncion_Load(object sender, EventArgs e)
        {
            CargarFunciones();
            CargarComboPeliculas();
            CargarComboSalas();
        }

        private void btNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            modo = "nuevo";

            tbIDFuncion.ReadOnly = tabla.Columns["IDFuncion"].AutoIncrement;

            cbPelicula.Focus();
        }

        private void btEditar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una función en la tabla.");
                return;
            }

            filaEditando = ((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;

            tbIDFuncion.Text = filaEditando["IDFuncion"].ToString();
            cbPelicula.SelectedValue = filaEditando["IDPelicula"];
            cbSala.SelectedValue = filaEditando["IDSala"];

            if (filaEditando["Fecha"] == DBNull.Value)
                dtpFecha.Value = DateTime.Today;
            else
                dtpFecha.Value = Convert.ToDateTime(filaEditando["Fecha"]);

            if (filaEditando["Hora"] == DBNull.Value)
                dtpHora.Value = DateTime.Today;
            else
            {
                int hora = Convert.ToInt32(filaEditando["Hora"]);
                dtpHora.Value = DateTime.Today.AddHours(hora / 100).AddMinutes(hora % 100);
            }

            tbIDFuncion.ReadOnly = true;

            modo = "editar";
            cbPelicula.Focus();
        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una función en la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Eliminar la función seleccionada?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                DataRowView filaSeleccionada = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
                filaSeleccionada.Row.Delete();

                adaptador.Update(tabla);

                modo = "";
                LimpiarCampos();
                CargarFunciones();

                MessageBox.Show("Función eliminada.");
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo eliminar: " + ex.Message);
            }
        }

        private void btGuardar_Click(object sender, EventArgs e)
        {
            if (modo == "")
            {
                MessageBox.Show("Primero pulsa Nuevo o Editar.");
                return;
            }

            if (cbPelicula.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona una película.");
                cbPelicula.Focus();
                return;
            }

            if (cbSala.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona una sala.");
                cbSala.Focus();
                return;
            }

            int idFuncion = 0;
            if (!tabla.Columns["IDFuncion"].AutoIncrement &&
                !int.TryParse(tbIDFuncion.Text, out idFuncion))
            {
                MessageBox.Show("ID Función debe ser un número.");
                tbIDFuncion.Focus();
                return;
            }

            int idPelicula = Convert.ToInt32(cbPelicula.SelectedValue);
            int idSala = Convert.ToInt32(cbSala.SelectedValue);
            DateTime fecha = dtpFecha.Value.Date;
            int hora = dtpHora.Value.Hour * 100 + dtpHora.Value.Minute;

            try
            {
                if (modo == "nuevo")
                {
                    DataRow fila = tabla.NewRow();

                    if (!tabla.Columns["IDFuncion"].AutoIncrement)
                        fila["IDFuncion"] = idFuncion;

                    fila["IDPelicula"] = idPelicula;
                    fila["IDSala"] = idSala;
                    fila["Fecha"] = fecha;
                    fila["Hora"] = hora;

                    tabla.Rows.Add(fila);
                }
                else if (modo == "editar")
                {
                    filaEditando["IDPelicula"] = idPelicula;
                    filaEditando["IDSala"] = idSala;
                    filaEditando["Fecha"] = fecha;
                    filaEditando["Hora"] = hora;
                }

                adaptador.Update(tabla);

                modo = "";
                LimpiarCampos();
                CargarFunciones();

                MessageBox.Show("Función guardada.");
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo guardar: " + ex.Message);
            }
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            modo = "";
            LimpiarCampos();
        }

        private void btObtener_Click(object sender, EventArgs e)
        {
            CargarFunciones();
            CargarComboPeliculas();
            CargarComboSalas();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
