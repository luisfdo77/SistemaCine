﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cine
{
    public partial class FrmVenta : Form
    {

        private string cadenaConexion = @"Server=.\SQLEXPRESS;Database=Cine;Integrated Security=True;TrustServerCertificate=True;";
        private SqlDataAdapter adaptador;
        private DataTable tabla;
        private string modo = "";
        private DataRow filaEditando;
        public FrmVenta()
        {
            InitializeComponent();
        }

        private void CargarVentas()
        {
            adaptador = new SqlDataAdapter("SELECT * FROM dbo.Venta ORDER BY IDVenta DESC", cadenaConexion);

            SqlCommandBuilder constructor = new SqlCommandBuilder(adaptador);

            adaptador.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            tabla = new DataTable();
            adaptador.Fill(tabla);

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = tabla;
        }

        private void CargarComboClientes()
        {
            SqlDataAdapter adaptadorCombo = new SqlDataAdapter(
                "SELECT IDCliente, Nombre FROM dbo.Cliente ORDER BY Nombre",
                cadenaConexion);

            DataTable tablaCombo = new DataTable();
            adaptadorCombo.Fill(tablaCombo);

            cbCliente.DataSource = tablaCombo;
            cbCliente.DisplayMember = "Nombre";
            cbCliente.ValueMember = "IDCliente";
            cbCliente.SelectedIndex = -1;
        }

        private void CargarComboFunciones()
        {
            SqlDataAdapter adaptadorCombo = new SqlDataAdapter(
                "SELECT f.IDFuncion, " +
                "p.NombrePelicula + ' | ' + su.Nombre + ' Sala ' + CAST(s.NumeroSala AS varchar) + ' | ' + " +
                "ISNULL(CONVERT(varchar(10), f.Fecha, 103), '') + ' ' + " +
                "ISNULL(STUFF(RIGHT('0000' + CAST(f.Hora AS varchar(4)), 4), 3, 0, ':'), '') AS Descripcion " +
                "FROM dbo.Funcion f " +
                "INNER JOIN dbo.Pelicula p ON f.IDPelicula = p.IDPelicula " +
                "INNER JOIN dbo.Sala s ON f.IDSala = s.IDSala " +
                "INNER JOIN dbo.Sucursal su ON s.IDSucursal = su.IDSucursal " +
                "ORDER BY f.Fecha DESC, f.Hora",
                cadenaConexion);

            DataTable tablaCombo = new DataTable();
            adaptadorCombo.Fill(tablaCombo);

            cbFuncion.DataSource = tablaCombo;
            cbFuncion.DisplayMember = "Descripcion";
            cbFuncion.ValueMember = "IDFuncion";
            cbFuncion.SelectedIndex = -1;
        }

        private void CargarComboTiposBoleto()
        {
            SqlDataAdapter adaptadorCombo = new SqlDataAdapter(
                "SELECT IDTipoBoleto, Clave, Precio FROM dbo.TipoBoleto ORDER BY Clave",
                cadenaConexion);

            DataTable tablaCombo = new DataTable();
            adaptadorCombo.Fill(tablaCombo);

            cbTipoBoleto.DataSource = tablaCombo;
            cbTipoBoleto.DisplayMember = "Clave";
            cbTipoBoleto.ValueMember = "IDTipoBoleto";
            cbTipoBoleto.SelectedIndex = -1;
        }

        private void LimpiarCampos()
        {
            tbIDVenta.Clear();
            cbCliente.SelectedIndex = -1;
            cbFuncion.SelectedIndex = -1;
            cbTipoBoleto.SelectedIndex = -1;
            tbPrecio.Clear();
        }


        private void gbDatos_Enter(object sender, EventArgs e)
        {

        }

        private void FrmVenta_Load(object sender, EventArgs e)
        {
            CargarVentas();
            CargarComboClientes();
            CargarComboFunciones();
            CargarComboTiposBoleto();
        }

        private void btNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            modo = "nuevo";

            tbIDVenta.ReadOnly = tabla.Columns["IDVenta"].AutoIncrement;

            cbCliente.Focus();
        }

        private void btEditar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una venta en la tabla.");
                return;
            }

            filaEditando = ((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;

            tbIDVenta.Text = filaEditando["IDVenta"].ToString();

            if (filaEditando["IDCliente"] == DBNull.Value)
                cbCliente.SelectedIndex = -1;
            else
                cbCliente.SelectedValue = filaEditando["IDCliente"];

            cbFuncion.SelectedValue = filaEditando["IDFuncion"];
            cbTipoBoleto.SelectedValue = filaEditando["IDTipoBoleto"];

            tbPrecio.Text = Convert.ToDecimal(filaEditando["Precio"]).ToString("0.00");

            tbIDVenta.ReadOnly = true;

            modo = "editar";
            cbCliente.Focus();
        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una venta en la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Eliminar la venta seleccionada?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                DataRowView filaSeleccionada = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
                filaSeleccionada.Row.Delete();

                adaptador.Update(tabla);

                modo = "";
                LimpiarCampos();
                CargarVentas();

                MessageBox.Show("Venta eliminada.");
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo eliminar: " + ex.Message);
            }
        }

        private void btGuardar_Click(object sender, EventArgs e)
        {
            if (modo == "")
            {
                MessageBox.Show("Primero pulsa Nuevo o Editar.");
                return;
            }

            if (cbFuncion.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona una función.");
                cbFuncion.Focus();
                return;
            }

            if (cbTipoBoleto.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona un tipo de boleto.");
                cbTipoBoleto.Focus();
                return;
            }

            decimal precio;
            if (!decimal.TryParse(tbPrecio.Text, out precio))
            {
                MessageBox.Show("El tipo de boleto seleccionado no tiene precio.");
                cbTipoBoleto.Focus();
                return;
            }

            int idVenta = 0;
            if (!tabla.Columns["IDVenta"].AutoIncrement &&
                !int.TryParse(tbIDVenta.Text, out idVenta))
            {
                MessageBox.Show("ID Venta debe ser un número.");
                tbIDVenta.Focus();
                return;
            }

            object idCliente = cbCliente.SelectedIndex == -1 ? (object)DBNull.Value : cbCliente.SelectedValue;
            int idFuncion = Convert.ToInt32(cbFuncion.SelectedValue);
            int idTipoBoleto = Convert.ToInt32(cbTipoBoleto.SelectedValue);

            try
            {
                if (modo == "nuevo")
                {
                    DataRow fila = tabla.NewRow();

                    if (!tabla.Columns["IDVenta"].AutoIncrement)
                        fila["IDVenta"] = idVenta;

                    fila["IDCliente"] = idCliente;
                    fila["IDFuncion"] = idFuncion;
                    fila["IDTipoBoleto"] = idTipoBoleto;
                    fila["Precio"] = precio;

                    tabla.Rows.Add(fila);
                }
                else if (modo == "editar")
                {
                    filaEditando["IDCliente"] = idCliente;
                    filaEditando["IDFuncion"] = idFuncion;
                    filaEditando["IDTipoBoleto"] = idTipoBoleto;
                    filaEditando["Precio"] = precio;
                }

                adaptador.Update(tabla);

                modo = "";
                LimpiarCampos();
                CargarVentas();

                MessageBox.Show("Venta guardada.");
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo guardar: " + ex.Message);
            }
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            modo = "";
            LimpiarCampos();
        }

        private void btObtener_Click(object sender, EventArgs e)
        {
            CargarVentas();
            CargarComboClientes();
            CargarComboFunciones();
            CargarComboTiposBoleto();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbTipoBoleto_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTipoBoleto.SelectedIndex == -1)
            {
                tbPrecio.Clear();
                return;
            }

            DataRowView tipo = (DataRowView)cbTipoBoleto.SelectedItem;

            if (tipo["Precio"] == DBNull.Value)
                tbPrecio.Clear();
            else
                tbPrecio.Text = Convert.ToDecimal(tipo["Precio"]).ToString("0.00");
        }
    }
}
