﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cine
{
    public partial class FrmUbicacion : Form
    {

        private string cadenaConexion = @"Server=.\SQLEXPRESS;Database=Cine;Integrated Security=True;TrustServerCertificate=True;";

        private SqlDataAdapter adaptadorEstados;
        private DataTable tablaEstados;
        private string modoEstado = "";
        private DataRow filaEditandoEstado;

        private SqlDataAdapter adaptadorCiudades;
        private DataTable tablaCiudades;
        private string modoCiudad = "";
        private DataRow filaEditandoCiudad;

        public FrmUbicacion()
        {
            InitializeComponent();
        }

        private void CargarEstados()
        {
            adaptadorEstados = new SqlDataAdapter("SELECT * FROM dbo.Estado", cadenaConexion);

            SqlCommandBuilder constructor = new SqlCommandBuilder(adaptadorEstados);

            adaptadorEstados.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            tablaEstados = new DataTable();
            adaptadorEstados.Fill(tablaEstados);

            dgvEstados.AutoGenerateColumns = true;
            dgvEstados.DataSource = tablaEstados;
            CargarComboEstados();
        }

        private void LimpiarCamposEstado()
        {
            tbIDEstado.Clear();
            tbSiglaEstado.Clear();
            tbClaveEstado.Clear();
            tbNombreEstado.Clear();
        }

        private void CargarCiudades()
        {
            adaptadorCiudades = new SqlDataAdapter("SELECT * FROM dbo.Ciudad", cadenaConexion);

            SqlCommandBuilder constructor = new SqlCommandBuilder(adaptadorCiudades);

            adaptadorCiudades.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            tablaCiudades = new DataTable();
            adaptadorCiudades.Fill(tablaCiudades);

            dgvCiudades.AutoGenerateColumns = true;
            dgvCiudades.DataSource = tablaCiudades;
        }

        private void CargarComboEstados()
        {
            SqlDataAdapter adaptadorCombo = new SqlDataAdapter(
                "SELECT IDEstado, NombreEstado FROM dbo.Estado ORDER BY NombreEstado",
                cadenaConexion);

            DataTable tablaCombo = new DataTable();
            adaptadorCombo.Fill(tablaCombo);

            cbEstado.DataSource = tablaCombo;
            cbEstado.DisplayMember = "NombreEstado";
            cbEstado.ValueMember = "IDEstado";
            cbEstado.SelectedIndex = -1;
        }

        private void LimpiarCamposCiudad()
        {
            tbIDCiudad.Clear();
            cbEstado.SelectedIndex = -1;
            tbSiglasCiudad.Clear();
            tbClaveCiudad.Clear();
            tbNombreCiudad.Clear();
        }

        private void FrmUbicacion_Load(object sender, EventArgs e)
        {
            CargarEstados();
            CargarCiudades();
        }

        private void btNuevoEstado_Click(object sender, EventArgs e)
        {
            LimpiarCamposEstado();
            modoEstado = "nuevo";

            tbIDEstado.ReadOnly = tablaEstados.Columns["IDEstado"].AutoIncrement;

            tbSiglaEstado.Focus();
        }

        private void btEditarEstado_Click(object sender, EventArgs e)
        {
            if (dgvEstados.CurrentRow == null)
            {
                MessageBox.Show("Selecciona un estado en la tabla.");
                return;
            }

            filaEditandoEstado = ((DataRowView)dgvEstados.CurrentRow.DataBoundItem).Row;

            tbIDEstado.Text = filaEditandoEstado["IDEstado"].ToString();
            tbSiglaEstado.Text = filaEditandoEstado["SiglaEstado"].ToString();
            tbClaveEstado.Text = filaEditandoEstado["ClaveEstado"].ToString();
            tbNombreEstado.Text = filaEditandoEstado["NombreEstado"].ToString();

            tbIDEstado.ReadOnly = true;

            modoEstado = "editar";
            tbSiglaEstado.Focus();
        }

        private void btEliminarEstado_Click(object sender, EventArgs e)
        {
            if (dgvEstados.CurrentRow == null)
            {
                MessageBox.Show("Selecciona un estado en la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Eliminar el estado seleccionado?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                DataRowView filaSeleccionada = (DataRowView)dgvEstados.CurrentRow.DataBoundItem;
                filaSeleccionada.Row.Delete();

                adaptadorEstados.Update(tablaEstados);

                MessageBox.Show("Estado eliminado.");
                modoEstado = "";
                LimpiarCamposEstado();
                CargarEstados();
            }
            catch (Exception ex)
            {
                tablaEstados.RejectChanges();
                MessageBox.Show("No se pudo eliminar: " + ex.Message);
            }
        }

        private void btGuardarEstado_Click(object sender, EventArgs e)
        {
            if (modoEstado == "")
            {
                MessageBox.Show("Primero pulsa Nuevo o Editar.");
                return;
            }

            if (tbSiglaEstado.Text.Trim() == "")
            {
                MessageBox.Show("La sigla es obligatoria.");
                tbSiglaEstado.Focus();
                return;
            }

            int idEstado = 0;
            if (!tablaEstados.Columns["IDEstado"].AutoIncrement &&
                !int.TryParse(tbIDEstado.Text, out idEstado))
            {
                MessageBox.Show("ID Estado debe ser un número.");
                tbIDEstado.Focus();
                return;
            }

            int claveEstado = 0;
            if (tbClaveEstado.Text.Trim() != "" &&
                !int.TryParse(tbClaveEstado.Text, out claveEstado))
            {
                MessageBox.Show("La clave debe ser un número.");
                tbClaveEstado.Focus();
                return;
            }

            try
            {
                if (modoEstado == "nuevo")
                {
                    DataRow fila = tablaEstados.NewRow();

                    if (!tablaEstados.Columns["IDEstado"].AutoIncrement)
                        fila["IDEstado"] = idEstado;

                    fila["SiglaEstado"] = tbSiglaEstado.Text.Trim();
                    fila["ClaveEstado"] = tbClaveEstado.Text.Trim() == "" ? (object)DBNull.Value : claveEstado;
                    fila["NombreEstado"] = tbNombreEstado.Text.Trim() == "" ? (object)DBNull.Value : tbNombreEstado.Text.Trim();

                    tablaEstados.Rows.Add(fila);
                }
                else if (modoEstado == "editar")
                {
                    filaEditandoEstado["SiglaEstado"] = tbSiglaEstado.Text.Trim();
                    filaEditandoEstado["ClaveEstado"] = tbClaveEstado.Text.Trim() == "" ? (object)DBNull.Value : claveEstado;
                    filaEditandoEstado["NombreEstado"] = tbNombreEstado.Text.Trim() == "" ? (object)DBNull.Value : tbNombreEstado.Text.Trim();
                }

                adaptadorEstados.Update(tablaEstados);

                MessageBox.Show("Estado guardado.");
                modoEstado = "";
                LimpiarCamposEstado();
                CargarEstados();
            }
            catch (Exception ex)
            {
                tablaEstados.RejectChanges();
                MessageBox.Show("No se pudo guardar: " + ex.Message);
            }
        }

        private void btCancelarEstado_Click(object sender, EventArgs e)
        {
            modoEstado = "";
            LimpiarCamposEstado();
        }

        private void btObtenerEstado_Click(object sender, EventArgs e)
        {
            CargarEstados();
        }

        private void btSalirEstado_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btNuevoCiudad_Click(object sender, EventArgs e)
        {
            LimpiarCamposCiudad();
            modoCiudad = "nuevo";

            tbIDCiudad.ReadOnly = tablaCiudades.Columns["IDCiudad"].AutoIncrement;

            cbEstado.Focus();
        }

        private void btEditarCiudad_Click(object sender, EventArgs e)
        {
            if (dgvCiudades.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una ciudad en la tabla.");
                return;
            }

            filaEditandoCiudad = ((DataRowView)dgvCiudades.CurrentRow.DataBoundItem).Row;

            tbIDCiudad.Text = filaEditandoCiudad["IDCiudad"].ToString();
            cbEstado.SelectedValue = filaEditandoCiudad["IDEstado"];
            tbSiglasCiudad.Text = filaEditandoCiudad["SiglasCiudad"].ToString();
            tbClaveCiudad.Text = filaEditandoCiudad["ClaveCiudad"].ToString();
            tbNombreCiudad.Text = filaEditandoCiudad["NombreCiudad"].ToString();

            tbIDCiudad.ReadOnly = true;

            modoCiudad = "editar";
            cbEstado.Focus();
        }

        private void btEliminarCiudad_Click(object sender, EventArgs e)
        {
            if (dgvCiudades.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una ciudad en la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Eliminar la ciudad seleccionada?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                DataRowView filaSeleccionada = (DataRowView)dgvCiudades.CurrentRow.DataBoundItem;
                filaSeleccionada.Row.Delete();

                adaptadorCiudades.Update(tablaCiudades);

                MessageBox.Show("Ciudad eliminada.");
                modoCiudad = "";
                LimpiarCamposCiudad();
                CargarCiudades();
            }
            catch (Exception ex)
            {
                tablaCiudades.RejectChanges();
                MessageBox.Show("No se pudo eliminar: " + ex.Message);
            }
        }

        private void btGuardarCiudad_Click(object sender, EventArgs e)
        {
            if (modoCiudad == "")
            {
                MessageBox.Show("Primero pulsa Nuevo o Editar.");
                return;
            }

            if (cbEstado.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona un estado.");
                cbEstado.Focus();
                return;
            }

            if (tbSiglasCiudad.Text.Trim() == "")
            {
                MessageBox.Show("Las siglas son obligatorias.");
                tbSiglasCiudad.Focus();
                return;
            }

            int claveCiudad;
            if (!int.TryParse(tbClaveCiudad.Text, out claveCiudad))
            {
                MessageBox.Show("La clave debe ser un número.");
                tbClaveCiudad.Focus();
                return;
            }

            if (tbNombreCiudad.Text.Trim() == "")
            {
                MessageBox.Show("El nombre es obligatorio.");
                tbNombreCiudad.Focus();
                return;
            }

            int idCiudad = 0;
            if (!tablaCiudades.Columns["IDCiudad"].AutoIncrement &&
                !int.TryParse(tbIDCiudad.Text, out idCiudad))
            {
                MessageBox.Show("ID Ciudad debe ser un número.");
                tbIDCiudad.Focus();
                return;
            }

            int idEstado = Convert.ToInt32(cbEstado.SelectedValue);

            try
            {
                if (modoCiudad == "nuevo")
                {
                    DataRow fila = tablaCiudades.NewRow();

                    if (!tablaCiudades.Columns["IDCiudad"].AutoIncrement)
                        fila["IDCiudad"] = idCiudad;

                    fila["IDEstado"] = idEstado;
                    fila["SiglasCiudad"] = tbSiglasCiudad.Text.Trim();
                    fila["ClaveCiudad"] = claveCiudad;
                    fila["NombreCiudad"] = tbNombreCiudad.Text.Trim();

                    tablaCiudades.Rows.Add(fila);
                }
                else if (modoCiudad == "editar")
                {
                    filaEditandoCiudad["IDEstado"] = idEstado;
                    filaEditandoCiudad["SiglasCiudad"] = tbSiglasCiudad.Text.Trim();
                    filaEditandoCiudad["ClaveCiudad"] = claveCiudad;
                    filaEditandoCiudad["NombreCiudad"] = tbNombreCiudad.Text.Trim();
                }

                adaptadorCiudades.Update(tablaCiudades);

                MessageBox.Show("Ciudad guardada.");
                modoCiudad = "";
                LimpiarCamposCiudad();
                CargarCiudades();
            }
            catch (Exception ex)
            {
                tablaCiudades.RejectChanges();
                MessageBox.Show("No se pudo guardar: " + ex.Message);
            }
        }

        private void btCancelarCiudad_Click(object sender, EventArgs e)
        {
            modoCiudad = "";
            LimpiarCamposCiudad();
        }

        private void btObtenerCiudad_Click(object sender, EventArgs e)
        {
            CargarCiudades();
            CargarComboEstados();
        }

        private void btSalirCiudad_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
