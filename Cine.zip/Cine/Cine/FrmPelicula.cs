﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cine
{
    public partial class FrmPelicula : Form
    {
        private string cadenaConexion = @"Server=.\SQLEXPRESS;Database=Cine;Integrated Security=True;TrustServerCertificate=True;";
        private SqlDataAdapter adaptador;
        private DataTable tabla;
        private string modo = "";
        private DataRow filaEditando;

        public FrmPelicula()
        {
            InitializeComponent();
        }

        private void CargarPeliculas()
        {
            adaptador = new SqlDataAdapter("SELECT * FROM dbo.Pelicula", cadenaConexion);

            SqlCommandBuilder constructor = new SqlCommandBuilder(adaptador);

            adaptador.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            tabla = new DataTable();
            adaptador.Fill(tabla);

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = tabla;
        }

        private void CargarComboGeneros()
        {
            SqlDataAdapter adaptadorCombo = new SqlDataAdapter(
                "SELECT IDGenero, NombreGenero FROM dbo.Genero ORDER BY NombreGenero",
                cadenaConexion);

            DataTable tablaCombo = new DataTable();
            adaptadorCombo.Fill(tablaCombo);

            cbGenero.DataSource = tablaCombo;
            cbGenero.DisplayMember = "NombreGenero";
            cbGenero.ValueMember = "IDGenero";
            cbGenero.SelectedIndex = -1;
        }

        private void CargarComboClasificaciones()
        {
            SqlDataAdapter adaptadorCombo = new SqlDataAdapter(
                "SELECT IDClasificacion, Clave FROM dbo.Clasificacion ORDER BY Clave",
                cadenaConexion);

            DataTable tablaCombo = new DataTable();
            adaptadorCombo.Fill(tablaCombo);

            cbClasificacion.DataSource = tablaCombo;
            cbClasificacion.DisplayMember = "Clave";
            cbClasificacion.ValueMember = "IDClasificacion";
            cbClasificacion.SelectedIndex = -1;
        }

        private void LimpiarCampos()
        {
            tbIDPelicula.Clear();
            tbNombrePelicula.Clear();
            tbDuracion.Clear();
            cbGenero.SelectedIndex = -1;
            cbClasificacion.SelectedIndex = -1;
        }

        private void FrmPelicula_Load(object sender, EventArgs e)
        {
            CargarPeliculas();
            CargarComboGeneros();
            CargarComboClasificaciones();
        }

        private void btNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            modo = "nuevo";

            tbIDPelicula.ReadOnly = tabla.Columns["IDPelicula"].AutoIncrement;

            tbNombrePelicula.Focus();
        }

        private void btEditar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una película en la tabla.");
                return;
            }

            filaEditando = ((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;

            tbIDPelicula.Text = filaEditando["IDPelicula"].ToString();
            tbNombrePelicula.Text = filaEditando["NombrePelicula"].ToString();
            tbDuracion.Text = filaEditando["Duracion"].ToString();
            cbGenero.SelectedValue = filaEditando["IDGenero"];
            cbClasificacion.SelectedValue = filaEditando["IDClasificacion"];

            tbIDPelicula.ReadOnly = true;

            modo = "editar";
            tbNombrePelicula.Focus();
        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una película en la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Eliminar la película seleccionada?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                DataRowView filaSeleccionada = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
                filaSeleccionada.Row.Delete();

                adaptador.Update(tabla);

                modo = "";
                LimpiarCampos();
                CargarPeliculas();

                MessageBox.Show("Película eliminada.");
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo eliminar: " + ex.Message);
            }
        }

        private void btGuardar_Click(object sender, EventArgs e)
        {
            if (modo == "")
            {
                MessageBox.Show("Primero pulsa Nuevo o Editar.");
                return;
            }

            if (tbNombrePelicula.Text.Trim() == "")
            {
                MessageBox.Show("El nombre de la película es obligatorio.");
                tbNombrePelicula.Focus();
                return;
            }

            int duracion;
            if (!int.TryParse(tbDuracion.Text, out duracion) || duracion <= 0)
            {
                MessageBox.Show("La duración debe ser un número de minutos mayor a 0.");
                tbDuracion.Focus();
                return;
            }

            if (cbGenero.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona un género.");
                cbGenero.Focus();
                return;
            }

            if (cbClasificacion.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona una clasificación.");
                cbClasificacion.Focus();
                return;
            }

            int idPelicula = 0;
            if (!tabla.Columns["IDPelicula"].AutoIncrement &&
                !int.TryParse(tbIDPelicula.Text, out idPelicula))
            {
                MessageBox.Show("ID Película debe ser un número.");
                tbIDPelicula.Focus();
                return;
            }

            int idGenero = Convert.ToInt32(cbGenero.SelectedValue);
            int idClasificacion = Convert.ToInt32(cbClasificacion.SelectedValue);

            try
            {
                if (modo == "nuevo")
                {
                    DataRow fila = tabla.NewRow();

                    if (!tabla.Columns["IDPelicula"].AutoIncrement)
                        fila["IDPelicula"] = idPelicula;

                    fila["NombrePelicula"] = tbNombrePelicula.Text.Trim();
                    fila["Duracion"] = duracion;
                    fila["IDGenero"] = idGenero;
                    fila["IDClasificacion"] = idClasificacion;

                    tabla.Rows.Add(fila);
                }
                else if (modo == "editar")
                {
                    filaEditando["NombrePelicula"] = tbNombrePelicula.Text.Trim();
                    filaEditando["Duracion"] = duracion;
                    filaEditando["IDGenero"] = idGenero;
                    filaEditando["IDClasificacion"] = idClasificacion;
                }

                adaptador.Update(tabla);

                modo = "";
                LimpiarCampos();
                CargarPeliculas();

                MessageBox.Show("Película guardada.");
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo guardar: " + ex.Message);
            }
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            modo = "";
            LimpiarCampos();
        }

        private void btObtener_Click(object sender, EventArgs e)
        {
            CargarPeliculas();
            CargarComboGeneros();
            CargarComboClasificaciones();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
