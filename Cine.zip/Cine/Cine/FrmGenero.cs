﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cine
{
    public partial class FrmGenero : Form
    {
        private string cadenaConexion = @"Server=.\SQLEXPRESS;Database=Cine;Integrated Security=True;TrustServerCertificate=True;";
        private SqlDataAdapter adaptador;
        private DataTable tabla;
        private string modo = "";
        private DataRow filaEditando;

        public FrmGenero()
        {
            InitializeComponent();
        }

        private void CargarGeneros()
        {
            adaptador = new SqlDataAdapter("SELECT * FROM dbo.Genero", cadenaConexion);

            SqlCommandBuilder constructor = new SqlCommandBuilder(adaptador);

            adaptador.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            tabla = new DataTable();
            adaptador.Fill(tabla);

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = tabla;
        }

        private void LimpiarCampos()
        {
            tbIDGenero.Clear();
            tbNombreGenero.Clear();
            tbDescripcionGenero.Clear();
        }

        private void btNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            modo = "nuevo";

            tbIDGenero.ReadOnly = tabla.Columns["IDGenero"].AutoIncrement;

            tbNombreGenero.Focus();
        }

        private void FrmGenero_Load(object sender, EventArgs e)
        {
            CargarGeneros();
        }

        private void btEditar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona un género en la tabla.");
                return;
            }

            filaEditando = ((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;

            tbIDGenero.Text = filaEditando["IDGenero"].ToString();
            tbNombreGenero.Text = filaEditando["NombreGenero"].ToString();
            tbDescripcionGenero.Text = filaEditando["DescripcionGenero"].ToString();

            tbIDGenero.ReadOnly = true;

            modo = "editar";
            tbNombreGenero.Focus();
        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona un género en la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Eliminar el género seleccionado?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                DataRowView filaSeleccionada = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
                filaSeleccionada.Row.Delete();

                adaptador.Update(tabla);

                MessageBox.Show("Género eliminado.");
                modo = "";
                LimpiarCampos();
                CargarGeneros();
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo eliminar: " + ex.Message);
            }
        }

        private void btGuardar_Click(object sender, EventArgs e)
        {
            if (modo == "")
            {
                MessageBox.Show("Primero pulsa Nuevo o Editar.");
                return;
            }

            if (tbNombreGenero.Text.Trim() == "")
            {
                MessageBox.Show("El nombre del género es obligatorio.");
                tbNombreGenero.Focus();
                return;
            }

            int idGenero = 0;
            if (!tabla.Columns["IDGenero"].AutoIncrement &&
                !int.TryParse(tbIDGenero.Text, out idGenero))
            {
                MessageBox.Show("ID Género debe ser un número.");
                tbIDGenero.Focus();
                return;
            }

            try
            {
                if (modo == "nuevo")
                {
                    DataRow fila = tabla.NewRow();

                    if (!tabla.Columns["IDGenero"].AutoIncrement)
                        fila["IDGenero"] = idGenero;

                    fila["NombreGenero"] = tbNombreGenero.Text.Trim();
                    fila["DescripcionGenero"] = tbDescripcionGenero.Text.Trim() == "" ? (object)DBNull.Value : tbDescripcionGenero.Text.Trim();

                    tabla.Rows.Add(fila);
                }
                else if (modo == "editar")
                {
                    filaEditando["NombreGenero"] = tbNombreGenero.Text.Trim();
                    filaEditando["DescripcionGenero"] = tbDescripcionGenero.Text.Trim() == "" ? (object)DBNull.Value : tbDescripcionGenero.Text.Trim();
                }

                adaptador.Update(tabla);

                MessageBox.Show("Género guardado.");
                modo = "";
                LimpiarCampos();
                CargarGeneros();
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo guardar: " + ex.Message);
            }
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            modo = "";
            LimpiarCampos();
        }

        private void btObtener_Click(object sender, EventArgs e)
        {
            CargarGeneros();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
