﻿namespace Cine
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbTitulo = new System.Windows.Forms.Label();
            this.btClientes = new System.Windows.Forms.Button();
            this.btClasificacion = new System.Windows.Forms.Button();
            this.btGenero = new System.Windows.Forms.Button();
            this.btPelicula = new System.Windows.Forms.Button();
            this.btSucursal = new System.Windows.Forms.Button();
            this.btSala = new System.Windows.Forms.Button();
            this.btTipoBoleto = new System.Windows.Forms.Button();
            this.btUbicacion = new System.Windows.Forms.Button();
            this.btFuncion = new System.Windows.Forms.Button();
            this.btVenta = new System.Windows.Forms.Button();
            this.btSalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbTitulo
            // 
            this.lbTitulo.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.Location = new System.Drawing.Point(235, 9);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(326, 63);
            this.lbTitulo.TabIndex = 0;
            this.lbTitulo.Text = "Sistema  de Cine";
            this.lbTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btClientes
            // 
            this.btClientes.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btClientes.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClientes.Location = new System.Drawing.Point(88, 91);
            this.btClientes.Name = "btClientes";
            this.btClientes.Size = new System.Drawing.Size(180, 60);
            this.btClientes.TabIndex = 1;
            this.btClientes.Text = "Clientes";
            this.btClientes.UseVisualStyleBackColor = false;
            this.btClientes.Click += new System.EventHandler(this.btClientes_Click);
            // 
            // btClasificacion
            // 
            this.btClasificacion.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btClasificacion.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClasificacion.Location = new System.Drawing.Point(308, 91);
            this.btClasificacion.Name = "btClasificacion";
            this.btClasificacion.Size = new System.Drawing.Size(180, 60);
            this.btClasificacion.TabIndex = 2;
            this.btClasificacion.Text = "Clasificación";
            this.btClasificacion.UseVisualStyleBackColor = false;
            this.btClasificacion.Click += new System.EventHandler(this.btClasificacion_Click);
            // 
            // btGenero
            // 
            this.btGenero.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btGenero.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGenero.Location = new System.Drawing.Point(517, 91);
            this.btGenero.Name = "btGenero";
            this.btGenero.Size = new System.Drawing.Size(180, 60);
            this.btGenero.TabIndex = 3;
            this.btGenero.Text = "Genero";
            this.btGenero.UseVisualStyleBackColor = false;
            this.btGenero.Click += new System.EventHandler(this.btGenero_Click);
            // 
            // btPelicula
            // 
            this.btPelicula.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btPelicula.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPelicula.Location = new System.Drawing.Point(88, 191);
            this.btPelicula.Name = "btPelicula";
            this.btPelicula.Size = new System.Drawing.Size(180, 60);
            this.btPelicula.TabIndex = 4;
            this.btPelicula.Text = "Película";
            this.btPelicula.UseVisualStyleBackColor = false;
            this.btPelicula.Click += new System.EventHandler(this.btPelicula_Click);
            // 
            // btSucursal
            // 
            this.btSucursal.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btSucursal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSucursal.Location = new System.Drawing.Point(308, 191);
            this.btSucursal.Name = "btSucursal";
            this.btSucursal.Size = new System.Drawing.Size(180, 60);
            this.btSucursal.TabIndex = 5;
            this.btSucursal.Text = "Sucursal";
            this.btSucursal.UseVisualStyleBackColor = false;
            this.btSucursal.Click += new System.EventHandler(this.btSucursal_Click);
            // 
            // btSala
            // 
            this.btSala.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btSala.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSala.Location = new System.Drawing.Point(517, 191);
            this.btSala.Name = "btSala";
            this.btSala.Size = new System.Drawing.Size(180, 60);
            this.btSala.TabIndex = 6;
            this.btSala.Text = "Sala";
            this.btSala.UseVisualStyleBackColor = false;
            this.btSala.Click += new System.EventHandler(this.btSala_Click);
            // 
            // btTipoBoleto
            // 
            this.btTipoBoleto.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btTipoBoleto.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTipoBoleto.Location = new System.Drawing.Point(88, 287);
            this.btTipoBoleto.Name = "btTipoBoleto";
            this.btTipoBoleto.Size = new System.Drawing.Size(180, 60);
            this.btTipoBoleto.TabIndex = 7;
            this.btTipoBoleto.Text = "Tipo de Boleto";
            this.btTipoBoleto.UseVisualStyleBackColor = false;
            this.btTipoBoleto.Click += new System.EventHandler(this.btTipoBoleto_Click);
            // 
            // btUbicacion
            // 
            this.btUbicacion.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btUbicacion.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btUbicacion.Location = new System.Drawing.Point(308, 287);
            this.btUbicacion.Name = "btUbicacion";
            this.btUbicacion.Size = new System.Drawing.Size(180, 60);
            this.btUbicacion.TabIndex = 8;
            this.btUbicacion.Text = "Ubicaciones";
            this.btUbicacion.UseVisualStyleBackColor = false;
            this.btUbicacion.Click += new System.EventHandler(this.btUbicacion_Click);
            // 
            // btFuncion
            // 
            this.btFuncion.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btFuncion.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btFuncion.Location = new System.Drawing.Point(517, 287);
            this.btFuncion.Name = "btFuncion";
            this.btFuncion.Size = new System.Drawing.Size(180, 60);
            this.btFuncion.TabIndex = 9;
            this.btFuncion.Text = "Función";
            this.btFuncion.UseVisualStyleBackColor = false;
            this.btFuncion.Click += new System.EventHandler(this.btFuncion_Click);
            // 
            // btVenta
            // 
            this.btVenta.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btVenta.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btVenta.Location = new System.Drawing.Point(308, 378);
            this.btVenta.Name = "btVenta";
            this.btVenta.Size = new System.Drawing.Size(180, 60);
            this.btVenta.TabIndex = 10;
            this.btVenta.Text = "Venta";
            this.btVenta.UseVisualStyleBackColor = false;
            this.btVenta.Click += new System.EventHandler(this.btVenta_Click);
            // 
            // btSalir
            // 
            this.btSalir.BackColor = System.Drawing.SystemColors.Highlight;
            this.btSalir.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSalir.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btSalir.Location = new System.Drawing.Point(677, 21);
            this.btSalir.Name = "btSalir";
            this.btSalir.Size = new System.Drawing.Size(100, 30);
            this.btSalir.TabIndex = 11;
            this.btSalir.Text = "Salir";
            this.btSalir.UseVisualStyleBackColor = false;
            this.btSalir.Click += new System.EventHandler(this.btSalir_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btSalir);
            this.Controls.Add(this.btVenta);
            this.Controls.Add(this.btFuncion);
            this.Controls.Add(this.btUbicacion);
            this.Controls.Add(this.btTipoBoleto);
            this.Controls.Add(this.btSala);
            this.Controls.Add(this.btSucursal);
            this.Controls.Add(this.btPelicula);
            this.Controls.Add(this.btGenero);
            this.Controls.Add(this.btClasificacion);
            this.Controls.Add(this.btClientes);
            this.Controls.Add(this.lbTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu Principal";
            this.Load += new System.EventHandler(this.FrmPrincipal_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.Button btClientes;
        private System.Windows.Forms.Button btClasificacion;
        private System.Windows.Forms.Button btGenero;
        private System.Windows.Forms.Button btPelicula;
        private System.Windows.Forms.Button btSucursal;
        private System.Windows.Forms.Button btSala;
        private System.Windows.Forms.Button btTipoBoleto;
        private System.Windows.Forms.Button btUbicacion;
        private System.Windows.Forms.Button btFuncion;
        private System.Windows.Forms.Button btVenta;
        private System.Windows.Forms.Button btSalir;
    }
}