﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cine
{
    public partial class FrmTipoBoleto : Form
    {
        private string cadenaConexion =
    @"Server=.\SQLEXPRESS;Database=Cine;Integrated Security=True;TrustServerCertificate=True;";
        private SqlDataAdapter adaptador;
        private DataTable tabla;
        private string modo = "";
        private DataRow filaEditando;

        public FrmTipoBoleto()
        {
            InitializeComponent();
        }

        private void CargarTiposBoleto()
        {
            adaptador = new SqlDataAdapter("SELECT * FROM dbo.TipoBoleto", cadenaConexion);

            SqlCommandBuilder constructor = new SqlCommandBuilder(adaptador);

            adaptador.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            tabla = new DataTable();
            adaptador.Fill(tabla);

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = tabla;
        }

        private void LimpiarCampos()
        {
            tbIDTipoBoleto.Clear();
            tbClave.Clear();
            tbDescripcion.Clear();
            tbPrecio.Clear();
        }

        private void FrmTipoBoleto_Load(object sender, EventArgs e)
        {
            CargarTiposBoleto();
        }

        private void gbDatos_Enter(object sender, EventArgs e)
        {

        }

        private void btNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            modo = "nuevo";

            tbIDTipoBoleto.ReadOnly = tabla.Columns["IDTipoBoleto"].AutoIncrement;

            tbClave.Focus();
        }

        private void btEditar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona un tipo de boleto en la tabla.");
                return;
            }

            filaEditando = ((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;

            tbIDTipoBoleto.Text = filaEditando["IDTipoBoleto"].ToString();
            tbClave.Text = filaEditando["Clave"].ToString();
            tbDescripcion.Text = filaEditando["Descripcion"].ToString();
            tbPrecio.Text = filaEditando["Precio"].ToString();

            tbIDTipoBoleto.ReadOnly = true;

            modo = "editar";
            tbClave.Focus();
        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Selecciona un tipo de boleto en la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Eliminar el tipo de boleto seleccionado?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                DataRowView filaSeleccionada = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
                filaSeleccionada.Row.Delete();

                adaptador.Update(tabla);

                MessageBox.Show("Tipo de boleto eliminado.");
                modo = "";
                LimpiarCampos();
                CargarTiposBoleto();
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo eliminar: " + ex.Message);
            }
        }

        private void btGuardar_Click(object sender, EventArgs e)
        {
            if (modo == "")
            {
                MessageBox.Show("Primero pulsa Nuevo o Editar.");
                return;
            }

            if (tbClave.Text.Trim() == "")
            {
                MessageBox.Show("La clave es obligatoria.");
                tbClave.Focus();
                return;
            }

            int idTipoBoleto = 0;
            if (!tabla.Columns["IDTipoBoleto"].AutoIncrement &&
                !int.TryParse(tbIDTipoBoleto.Text, out idTipoBoleto))
            {
                MessageBox.Show("ID Tipo Boleto debe ser un número.");
                tbIDTipoBoleto.Focus();
                return;
            }

            decimal precio = 0;
            if (tbPrecio.Text.Trim() != "" &&
                (!decimal.TryParse(tbPrecio.Text, out precio) || precio < 0))
            {
                MessageBox.Show("El precio debe ser un número mayor o igual a 0.");
                tbPrecio.Focus();
                return;
            }

            try
            {
                if (modo == "nuevo")
                {
                    DataRow fila = tabla.NewRow();

                    if (!tabla.Columns["IDTipoBoleto"].AutoIncrement)
                        fila["IDTipoBoleto"] = idTipoBoleto;

                    fila["Clave"] = tbClave.Text.Trim();
                    fila["Descripcion"] = tbDescripcion.Text.Trim() == "" ? (object)DBNull.Value : tbDescripcion.Text.Trim();
                    fila["Precio"] = tbPrecio.Text.Trim() == "" ? (object)DBNull.Value : precio;

                    tabla.Rows.Add(fila);
                }
                else if (modo == "editar")
                {
                    filaEditando["Clave"] = tbClave.Text.Trim();
                    filaEditando["Descripcion"] = tbDescripcion.Text.Trim() == "" ? (object)DBNull.Value : tbDescripcion.Text.Trim();
                    filaEditando["Precio"] = tbPrecio.Text.Trim() == "" ? (object)DBNull.Value : precio;
                }

                adaptador.Update(tabla);

                MessageBox.Show("Tipo de boleto guardado.");
                modo = "";
                LimpiarCampos();
                CargarTiposBoleto();
            }
            catch (Exception ex)
            {
                tabla.RejectChanges();
                MessageBox.Show("No se pudo guardar: " + ex.Message);
            }
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            modo = "";
            LimpiarCampos();
        }

        private void btObtener_Click(object sender, EventArgs e)
        {
            CargarTiposBoleto();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
